(()=>{
const $=id=>document.getElementById(id);
const store={get(k){try{return localStorage.getItem('plr:'+k)}catch(e){return null}},set(k,v){try{localStorage.setItem('plr:'+k,v)}catch(e){}}};
try{const wEl=$('pdfworker');if(wEl)pdfjsLib.GlobalWorkerOptions.workerSrc=URL.createObjectURL(new Blob([wEl.textContent],{type:'text/javascript'}))}catch(e){}

/* ---------- recent files (IndexedDB, this device only) ---------- */
const DB={
  db:null,
  open(){if(this.db)return Promise.resolve(this.db);return new Promise((res,rej)=>{let r;try{r=indexedDB.open('pdf-lecture-reader',1)}catch(e){rej(e);return}
    r.onupgradeneeded=()=>r.result.createObjectStore('files',{keyPath:'id'});r.onsuccess=()=>{this.db=r.result;res(r.result)};r.onerror=()=>rej(r.error)})},
  async tx(mode,fn){const db=await this.open();return new Promise((res,rej)=>{const t=db.transaction('files',mode),st=t.objectStore('files');const out=fn(st);t.oncomplete=()=>res(out&&out.result);t.onerror=()=>rej(t.error)})},
  async list(){const db=await this.open();return new Promise((res,rej)=>{const out=[];const c=db.transaction('files').objectStore('files').openCursor();
    c.onsuccess=()=>{const cur=c.result;if(cur){const {id,name,size,opened}=cur.value;out.push({id,name,size,opened});cur.continue()}else res(out.sort((a,b)=>b.opened-a.opened))};c.onerror=()=>rej(c.error)})},
  async get(id){const db=await this.open();return new Promise((res,rej)=>{const r=db.transaction('files').objectStore('files').get(id);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})},
  put(rec){return this.tx('readwrite',st=>st.put(rec))},
  del(id){return this.tx('readwrite',st=>st.delete(id))}
};
const ddmmyyyy=ms=>{const d=new Date(ms),p=n=>String(n).padStart(2,'0');return p(d.getDate())+'/'+p(d.getMonth()+1)+'/'+d.getFullYear()};
async function showRecent(){
  try{const list=await DB.list();const ul=$('recent');ul.innerHTML='';
    list.slice(0,8).forEach(r=>{const li=document.createElement('li');
      const b=document.createElement('button');b.className='name';b.textContent=r.name;b.title='Open '+r.name;b.onclick=()=>openRecent(r.id);
      const m=document.createElement('span');m.className='meta';m.textContent=(r.size/1048576).toFixed(1)+' MB · '+ddmmyyyy(r.opened);
      const x=document.createElement('button');x.className='x';x.textContent='Remove';x.setAttribute('aria-label','Remove '+r.name+' from recent');x.onclick=async()=>{await DB.del(r.id);showRecent()};
      li.append(b,m,x);ul.appendChild(li)});
    $('recentBox').hidden=!list.length;
  }catch(e){$('recentBox').hidden=true}
}
async function remember(id,name,buf){
  try{if(buf.byteLength>80*1048576)return;await DB.put({id,name,size:buf.byteLength,opened:Date.now(),data:buf});
    const list=await DB.list();for(const r of list.slice(8))await DB.del(r.id)}catch(e){}
}
async function openRecent(id){try{const r=await DB.get(id);if(r)openBuffer(r.data,r.name,true)}catch(e){showErr('That file could not be loaded from this device. Open it again from your files.')}}

/* ---------- open ---------- */
const fileIn=$('file'),drop=$('drop');
$('pick').onclick=e=>{e.stopPropagation();fileIn.click()};
drop.onclick=()=>fileIn.click();
drop.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fileIn.click()}};
fileIn.onchange=()=>{const f=fileIn.files[0];if(f)openFile(f);fileIn.value=''};
['dragenter','dragover'].forEach(t=>document.addEventListener(t,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(t=>document.addEventListener(t,e=>{e.preventDefault();if(t==='drop'||e.target===document.documentElement)drop.classList.remove('over')}));
document.addEventListener('drop',e=>{const f=[...(e.dataTransfer?.files||[])].find(f=>/pdf$/i.test(f.type)||/\.pdf$/i.test(f.name));if(f)openFile(f);else if(e.dataTransfer?.files?.length)showErr('That file is not a PDF. Drop a .pdf file.')});
function showErr(m){const e=$('err');e.textContent=m;e.hidden=!m}
async function openFile(f){showErr('');try{openBuffer(await f.arrayBuffer(),f.name)}catch(e){showErr('The file could not be read. Try choosing it again.')}}

/* ---------- state ---------- */
let pdf=null,DOC=null,ST=null,FP='',cur=0,shownSec=-1,CUR=null;
const measureCtx=document.createElement('canvas').getContext('2d');
const measure=(s,fs)=>{measureCtx.font=fs+'px sans-serif';return measureCtx.measureText(s).width};

async function openBuffer(buf,name,fromRecent){
  stop();showErr('');$('loading').hidden=false;$('loadtxt').textContent='Opening '+name+'…';$('loadbar').style.width='0%';
  try{
    if(pdf){try{pdf.destroy()}catch(e){}}
    pdf=await pdfjsLib.getDocument({data:new Uint8Array(buf.slice(0)),isEvalSupported:false}).promise;
    FP=(pdf.fingerprints&&pdf.fingerprints[0])||name;
    DOC=await Core.extract(pdf,pdfjsLib,measure,async(i,n)=>{$('loadtxt').textContent=`Reading page ${i} of ${n}…`;$('loadbar').style.width=(i/n*100)+'%';if(i%4===0)await new Promise(r=>setTimeout(r))});
    ST=Core.structure(DOC);CUR={buf,name};
    if(!fromRecent)remember(FP,name,buf);else DB.get(FP).then(r=>r&&DB.put(Object.assign(r,{opened:Date.now()}))).catch(()=>{});
    startApp(name);
  }catch(e){console.error(e);showErr(/password/i.test(e&&e.name||'')?'This PDF is password protected. Remove the password and try again.':'This file could not be opened as a PDF.')}
  finally{$('loading').hidden=true}
}

/* ---------- app view ---------- */
const pagesEl=$('pages'),pdfPane=$('pdf'),trPane=$('tr'),art=$('art'),main=$('main'),secSel=$('sec');
let PG=[];
function startApp(name){
  $('start').hidden=true;$('app').hidden=false;$('docname').textContent=name.replace(/\.pdf$/i,'');document.title=name.replace(/\.pdf$/i,'')+' · StudyDesk PDF';
  $('notext').hidden=ST.S.length>3;
  secSel.innerHTML=ST.secs.map((s,i)=>`<option value="${i}">${/^(\d+(\.\d+)*|[A-Z])[.):]?\s|^(part|chapter|section|unit|lesson|module)\b/i.test(s.title)?'':(i+1)+'. '}${esc(s.title)}</option>`).join('');
  buildPages();shownSec=-1;
  loadSplit();
  const saved=parseInt(store.get('pos:'+FP));cur=Number.isFinite(saved)&&saved<ST.S.length?saved:0;
  if(ST.S.length)show(cur,true);else{renderEmpty()}
}
$('home').onclick=()=>{stop();$('app').hidden=true;$('start').hidden=false;document.title='StudyDesk PDF';showRecent()};
const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function renderEmpty(){art.innerHTML='<p class="note">No readable text was found in this PDF.</p>'}

/* pages: placeholders, rendered lazily */
let io=null,zoom=1;
function buildPages(){
  pagesEl.innerHTML='';PG=[];if(io)io.disconnect();
  io=new IntersectionObserver(es=>es.forEach(e=>{const P=PG[+e.target.dataset.p];P.visible=e.isIntersecting;if(e.isIntersecting)renderPage(P)}),{root:pdfPane,rootMargin:'800px 0px'});
  DOC.pages.forEach((p,i)=>{
    const d=document.createElement('div');d.className='pg';d.dataset.p=i;d.style.aspectRatio=p.w+'/'+p.h;
    d.innerHTML=`<div class="ov"></div><span class="tag">Page ${i+1} of ${DOC.pages.length}</span>`;
    d.addEventListener('click',onPageClick);d.addEventListener('mousemove',onPageHover);d.addEventListener('mouseleave',()=>clearRects('hv'));
    pagesEl.appendChild(d);const P={i,el:d,ov:d.firstChild,w:p.w,h:p.h,scale:0,task:null};PG.push(P);io.observe(d);
  });
}
async function renderPage(P){
  const width=P.el.clientWidth;if(!width)return;
  const dpr=Math.min(window.devicePixelRatio||1,2.5);let scale=width*dpr/P.w;scale=Math.min(scale,5000/P.w);
  if(P.task||Math.abs(scale-P.scale)/scale<0.08)return;
  try{
    const page=await pdf.getPage(P.i+1);const vp=page.getViewport({scale});
    const c=document.createElement('canvas');c.width=Math.floor(vp.width);c.height=Math.floor(vp.height);
    P.task=page.render({canvasContext:c.getContext('2d'),viewport:vp});await P.task.promise;
    const old=P.el.querySelector('canvas');if(old)old.remove();P.el.insertBefore(c,P.el.firstChild);P.scale=scale;
  }catch(e){}finally{P.task=null}
  trimCanvases();
}
function trimCanvases(){ // keep memory in check on long PDFs
  const live=PG.filter(P=>P.scale);if(live.length<=16)return;
  live.filter(P=>!P.visible).forEach(P=>{const c=P.el.querySelector('canvas');if(c){c.width=0;c.remove()}P.scale=0})}
let rrT=0;function rerenderVisible(){clearTimeout(rrT);rrT=setTimeout(()=>PG.forEach(P=>{if(P.visible)renderPage(P)}),180)}
new ResizeObserver(rerenderVisible).observe(pdfPane);

/* highlight rectangles */
function clearRects(cls){document.querySelectorAll('.'+cls).forEach(e=>e.remove())}
function lineRects(ws){
  const out=[];let r=null;
  for(const wi of ws){const w=DOC.W[wi];
    if(r&&r.p===w.p&&Math.abs(w.y0-r.y0)<0.6&&w.x0>=r.x1-0.8&&w.x0-r.x1<8){r.x1=Math.max(r.x1,w.x1);r.y1=Math.max(r.y1,w.y1)}
    else{r={p:w.p,x0:w.x0,y0:w.y0,x1:w.x1,y1:w.y1};out.push(r)}}
  return out;
}
function draw(cls,ws){
  clearRects(cls);const els=[];
  for(const r of lineRects(ws)){const P=PG[r.p];if(!P)continue;const d=document.createElement('div');d.className=cls;
    Object.assign(d.style,{left:(r.x0-0.3)+'%',top:(r.y0-0.2)+'%',width:(r.x1-r.x0+0.6)+'%',height:(r.y1-r.y0+0.4)+'%'});P.ov.appendChild(d);els.push(d)}
  return els;
}
function wordAt(e){
  const el=e.currentTarget,p=+el.dataset.p,box=el.getBoundingClientRect(),P=DOC.pages[p];
  const x=(e.clientX-box.left)/box.width*100,y=(e.clientY-box.top)/box.height*100;
  let best=-1,bd=1e9;
  for(let g=P.wstart;g<P.wend;g++){const w=DOC.W[g];if(ST.w2s[g]<0)continue;
    const dx=x<w.x0?w.x0-x:x>w.x1?x-w.x1:0,dy=y<w.y0?w.y0-y:y>w.y1?y-w.y1:0,d=dx*dx+dy*dy*4;if(d<bd){bd=d;best=g}}
  return best>=0&&bd<6?best:null;
}
function onPageClick(e){const g=wordAt(e);if(g==null)return;jump(ST.w2s[g])}
let hvRaf=0;
function onPageHover(e){if(hvRaf)return;const ev={clientX:e.clientX,clientY:e.clientY,currentTarget:e.currentTarget};
  hvRaf=requestAnimationFrame(()=>{hvRaf=0;const g=wordAt(ev);const i=g==null?-1:ST.w2s[g];
    ev.currentTarget.style.cursor=i>=0?'pointer':'default';if(i<0||i===cur){clearRects('hv');return}draw('hv',ST.S[i].ws)})}

/* transcript, one section at a time */
function renderSection(k){
  const sec=ST.secs[k];art.innerHTML='';
  const eb=document.createElement('span');eb.className='eyebrow';eb.textContent=`Section ${k+1} of ${ST.secs.length} · page ${sec.page+1}`;art.appendChild(eb);
  let lastBlock=-1,el=null;
  for(let i=sec.first;i<=sec.last;i++){const s=ST.S[i];
    if(s.block!==lastBlock){const b=ST.blocks[s.block];lastBlock=s.block;
      el=document.createElement(b.type==='h'?('h'+Math.min(4,(b.level||1)+1)):'p');art.appendChild(el)}
    const sp=document.createElement('span');sp.className='s';sp.dataset.i=i;
    s.ws.forEach((wi,k2)=>{const t=DOC.W[wi].t,nx=DOC.W[s.ws[k2+1]];const w=document.createElement('span');w.className='w';w.dataset.w=wi;
      const join=/[A-Za-z]-$/.test(t)&&nx&&/^[a-z]/.test(nx.t)&&DOC.W[wi].y0!==nx.y0;
      w.textContent=join?t.slice(0,-1):t;sp.appendChild(w);if(!join)sp.appendChild(document.createTextNode(' '))});
    sp.onclick=()=>jump(i);el.appendChild(sp);s.el=sp;
  }
  const nav=document.createElement('div');nav.className='secnav';
  const note=document.createElement('span');note.className='note';note.textContent='Tap a sentence, or any word on the PDF, to read from there.';
  nav.appendChild(note);
  if(k<ST.secs.length-1){const nb=document.createElement('button');nb.textContent='Next section →';nb.onclick=()=>jump(ST.secs[k+1].first);nav.appendChild(nb)}
  art.appendChild(nav);
  shownSec=k;secSel.value=k;trPane.scrollTop=0;
}
secSel.onchange=()=>jump(ST.secs[+secSel.value].first);

const smooth=()=>matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth';
function within(pane,el,instant){
  const pr=pane.getBoundingClientRect(),r=el.getBoundingClientRect(),top=pane===pdfPane?56:30;
  if(r.top<pr.top+top||r.bottom>pr.bottom-40)pane.scrollTo({top:pane.scrollTop+r.top-pr.top-pr.height*0.4,behavior:instant?'auto':smooth()});
  if(pane===pdfPane&&(r.left<pr.left||r.right>pr.right))pane.scrollTo({left:Math.max(0,pane.scrollLeft+r.left-pr.left-30),behavior:instant?'auto':smooth()});
}
let lastPage=-1;
function show(i,instant){
  const s=ST.S[i];if(!s)return;
  if(s.sec!==shownSec)renderSection(s.sec);
  document.querySelectorAll('.s.cur').forEach(e=>e.classList.remove('cur'));
  document.querySelectorAll('.w.on').forEach(e=>e.classList.remove('on'));
  if(s.el){s.el.classList.add('cur');within(trPane,s.el,instant)}
  clearRects('hv');clearRects('hw');
  const els=draw('hl',s.ws);
  if(lastPage>=0&&PG[lastPage])PG[lastPage].el.classList.remove('on');
  if(PG[s.page])PG[s.page].el.classList.add('on');lastPage=s.page;
  if(els.length)within(pdfPane,els[0],instant);
  const sec=ST.secs[s.sec];
  $('now').textContent=`Section ${s.sec+1}/${ST.secs.length} · page ${s.page+1}`;
  $('pginfo').textContent=`Page ${s.page+1} of ${DOC.pages.length}`;
  $('prog').style.width=((i+1)/ST.S.length*100)+'%';
  store.set('pos:'+FP,i);
}
function markWord(wi){
  clearRects('hw');draw('hw',[wi]);
  document.querySelectorAll('.w.on').forEach(e=>e.classList.remove('on'));
  const s=ST.S[cur];if(s&&s.el){const w=s.el.querySelector(`[data-w="${wi}"]`);if(w)w.classList.add('on')}
}

/* ---------- speech, paced like a teacher ---------- */
const synth=window.speechSynthesis;
const vSel=$('voice'),rSel=$('rate'),pSel=$('pace'),playB=$('play');
let voices=[],playing=false,token=0,timer=null;
if(!synth){$('nosupport').hidden=false;playB.disabled=true}
/* ---------- voices: Indian voices first ---------- */
const LANGS=(()=>{try{return new Intl.DisplayNames(['en'],{type:'language',languageDisplay:'standard'})}catch(e){return null}})();
const normLang=l=>String(l||'').replace('_','-');
const langName=l=>{try{return (LANGS&&LANGS.of(normLang(l)))||l}catch(e){return l}};
const isIndian=v=>/-IN$/i.test(normLang(v.lang))||/\(India\)/.test(v.name);
const isEnIN=v=>/^en-IN$/i.test(normLang(v.lang));
const isHindi=v=>/^hi(-|$)/i.test(normLang(v.lang));
const isNatural=v=>/natural|neural|premium|enhanced/i.test(v.name);
const quality=v=>{const m=/natural|neural|premium|enhanced/i.exec(v.name);return m?(m[0].toLowerCase()==='neural'?'natural':m[0].toLowerCase()):''};
// macOS ships joke voices (Bells, Zarvox, Bad News…) that are no use for reading
const NOVELTY=/^(Albert|Bad News|Bahh|Bells|Boing|Bubbles|Cellos|Good News|Jester|Organ|Superstar|Trinoids|Whisper|Wobble|Zarvox)/;
function voiceName(v){
  const n=v.name.replace(/^Microsoft\s+/,'').replace(/\s+Online\s*\(Natural\)/i,'').replace(/\s+Desktop\b/,'').replace(/\s*\((Enhanced|Premium)\)/i,'').replace(/\s+-\s+.*$/,'').trim();
  return n||v.name;
}
function voiceDetails(v){
  const tags=[];if(quality(v))tags.push(quality(v));if(v.localService===false)tags.push('online');
  return langName(v.lang)+(tags.length?' · '+tags.join(', '):'');
}
const voiceLabel=v=>voiceName(v)+' · '+voiceDetails(v);
function rankIndian(v){return (isEnIN(v)?0:isHindi(v)?2:4)+(isNatural(v)?0:1)}
function voiceGroups(){
  const lang=(navigator.language||'en').slice(0,2).toLowerCase();
  const g={in:[],en:[],other:[]};
  voices.forEach((v,i)=>{(isIndian(v)?g.in:/^en/i.test(v.lang)?g.en:g.other).push(i)});
  const byName=(a,b)=>voices[a].name.localeCompare(voices[b].name);
  g.in.sort((a,b)=>rankIndian(voices[a])-rankIndian(voices[b])||byName(a,b));
  g.en.sort((a,b)=>(isNatural(voices[b])-isNatural(voices[a]))||byName(a,b));
  g.other.sort((a,b)=>(voices[b].lang.toLowerCase().startsWith(lang)-voices[a].lang.toLowerCase().startsWith(lang))||byName(a,b));
  return g;
}
function defaultVoice(g){
  const enIN=g.in.filter(i=>isEnIN(voices[i]));
  if(enIN.length)return enIN[0];
  if(g.en.length)return g.en[0];
  return g.in[0]??g.other[0]??0;
}
function loadVoices(){
  voices=synth.getVoices().filter(v=>!NOVELTY.test(v.name));if(!voices.length)return;
  const g=voiceGroups();
  const opt=i=>`<option value="${i}">${esc(voiceLabel(voices[i]))}</option>`;
  const grp=(label,list)=>list.length?`<optgroup label="${label}">${list.map(opt).join('')}</optgroup>`:'';
  vSel.innerHTML=grp('Indian voices',g.in)+grp('English voices',g.en)+grp('Other languages',g.other);
  const saved=store.get('voice'),pref=voices.findIndex(v=>v.name===saved);
  vSel.value=pref>=0?pref:defaultVoice(g);
  $('indcount').textContent=g.in.length?String(g.in.length):'';
  $('indcount').hidden=!g.in.length;
  if($('vdlg').open)renderVoicePanel();
}
function useVoice(i){
  vSel.value=i;store.set('voice',voices[i]?.name||'');
  if(playing)restart();
  renderVoicePanel();
}
function testVoice(i){
  const v=voices[i];if(!v)return;
  stop();
  const text=isHindi(v)?'नमस्ते! आपकी PDF इसी आवाज़ में पढ़ी जाएगी।':'Hello! This is how I will read your PDFs, with a short pause after every idea.';
  const u=new SpeechSynthesisUtterance(text);try{u.voice=v;u.lang=v.lang}catch(e){}u.rate=parseFloat(rSel.value);
  synth.speak(u);
}
function platform(){
  const ua=navigator.userAgent;
  const os=/Windows/.test(ua)?'win':/Macintosh|Mac OS X/.test(ua)?'mac':/CrOS/.test(ua)?'cros':'other';
  const where=(window.native&&window.native.desktop)?'app':/Edg\//.test(ua)?'edge':/Firefox\//.test(ua)?'firefox':'chrome';
  return {os,where};
}
function voiceHelp(hasEnIN){
  const {os,where}=platform();
  const restart=where==='app'?'StudyDesk PDF':'this browser';
  let h=`<h3 class="vgroup">${hasEnIN?'Add more Indian voices':'No Indian English voice found yet'}</h3>`;
  if(where==='edge')h+='<p>Microsoft Edge has natural Indian voices built in: <b>Neerja</b> and <b>Prabhat</b> (English, India) and <b>Swara</b> and <b>Madhur</b> (Hindi). They appear here when you are online.</p>';
  if(os==='win')h+=`<p>Add the Windows voices for India:</p><ol><li>Open <b>Settings → Time &amp; language → Speech</b>.</li><li>Under <b>Manage voices</b>, click <b>Add voices</b>.</li><li>Choose <b>English (India)</b>, and <b>Hindi</b> if you like, then click <b>Add</b>.</li><li>Close and reopen ${restart}.</li></ol>`;
  else if(os==='mac')h+=`<p>Add the macOS voices for India:</p><ol><li>Open <b>System Settings → Accessibility → Spoken Content</b>.</li><li>Next to <b>System voice</b>, choose <b>Manage Voices</b>.</li><li>Download the <b>English (India)</b> voices, and <b>Hindi</b> if you like.</li><li>Close and reopen ${restart}.</li></ol>`;
  else h+=`<p>Install an <b>English (India)</b> voice for your system's text-to-speech, then reopen ${restart}.</p>`;
  if(where==='chrome')h+='<p>Chrome itself includes only a Hindi voice (<b>Google हिन्दी</b>), not an Indian English one. For the most natural Indian English voices, use StudyDesk PDF in <b>Microsoft Edge</b>.</p>';
  if(where==='app'&&os==='win')h+='<p>Some voices added this way are only available to Microsoft Edge. If a new voice does not appear here after reopening, use the StudyDesk PDF browser extension in Edge.</p>';
  return h;
}
function renderVoicePanel(){
  const g=voiceGroups(),cur=+vSel.value;
  const list=$('vdlg-list');list.innerHTML='';
  if(!voices.length){list.innerHTML='<p class="vnone">No voices are available yet. Voices can take a few seconds to load.</p>'}
  else if(!g.in.length){list.innerHTML='<p class="vnone">This computer has no Indian voices installed yet. The steps below add them.</p>'}
  g.in.forEach(i=>{
    const v=voices[i],row=document.createElement('div');row.className='vrow'+(i===cur?' on':'');
    const t=document.createElement('div');const b=document.createElement('b');b.textContent=voiceName(v);const sp=document.createElement('span');sp.textContent=voiceDetails(v);t.append(b,sp);
    const test=document.createElement('button');test.type='button';test.textContent='Test';test.setAttribute('aria-label','Test '+voiceName(v));test.onclick=()=>testVoice(i);
    const use=document.createElement('button');use.type='button';
    if(i===cur){use.textContent='In use';use.disabled=true}else{use.textContent='Use';use.className='primary';use.setAttribute('aria-label','Use '+voiceName(v));use.onclick=()=>useVoice(i)}
    row.append(t,test,use);list.appendChild(row);
  });
  $('vdlg-help').innerHTML=voiceHelp(g.in.some(i=>isEnIN(voices[i])));
  const nb=$('vdlg-settings'),os=platform().os;
  const canOpen=!!(window.native&&window.native.openSpeechSettings)&&(os==='win'||os==='mac');
  nb.hidden=!canOpen;
  nb.textContent=os==='mac'?'Open Accessibility settings':'Open Windows speech settings';
}
$('indvoices').onclick=()=>{renderVoicePanel();try{$('vdlg').showModal()}catch(e){$('vdlg').setAttribute('open','')}};
$('vdlg-settings').onclick=()=>{try{window.native.openSpeechSettings()}catch(e){}};
$('vdlg').addEventListener('close',()=>{if(!playing&&synth)synth.cancel()});
if(synth){loadVoices();synth.onvoiceschanged=loadVoices}
[['rate',rSel],['pace',pSel]].forEach(([k,el])=>{const v=store.get(k);if(v&&[...el.options].some(o=>o.value===v))el.value=v;el.onchange=()=>store.set(k,el.value)});
vSel.onchange=()=>{store.set('voice',voices[vSel.value]?.name||'');if(playing)restart()};
rSel.addEventListener('change',()=>{if(playing)restart()});

const BASE={colon:420,comma:140,sent:650,para:1300,beforeHead:1500,afterHead:1500};
/* Online voices (for example Chrome's Google voices) stop after about 15 seconds of speech,
   so long sentences are cut at commas, or at spaces, into shorter pieces for them. */
function splitForVoice(list){
  const v=voices[vSel.value];
  if(!v||v.localService!==false)return list;
  const MAX=170,out=[];
  for(const ch of list){
    let text=ch.text,map=ch.map;
    while(text.length>MAX){
      let cut=text.lastIndexOf(', ',MAX);
      if(cut<MAX*0.4)cut=text.lastIndexOf(' ',MAX);
      if(cut<=0)break;
      cut+=1;
      out.push({text:text.slice(0,cut),map:map.filter(m=>m[0]<cut),gap:'comma'});
      text=text.slice(cut).replace(/^\s+/,m=>{cut+=m.length;return ''});
      map=map.filter(m=>m[0]>=cut).map(m=>[m[0]-cut,m[1]]);
    }
    out.push({text,map,gap:ch.gap});
  }
  return out;
}
const pause=k=>BASE[k]*parseFloat(pSel.value);
function sayChunks(list,k,my,done){
  if(my!==token)return;if(k>=list.length){done();return}
  const ch=list[k];const u=new SpeechSynthesisUtterance(ch.text);
  const v=voices[vSel.value];if(v){try{u.voice=v;u.lang=v.lang}catch(e){}}
  u.rate=parseFloat(rSel.value);
  u.onboundary=e=>{if(my!==token||e.name&&e.name!=='word')return;const m=ch.map;let lo=0,hi=m.length-1,f=0;
    while(lo<=hi){const mid=(lo+hi)>>1;if(m[mid][0]<=e.charIndex){f=mid;lo=mid+1}else hi=mid-1}if(m[f])markWord(m[f][1])};
  let ended=false;const next=()=>{if(ended||my!==token)return;ended=true;if(k<list.length-1)timer=setTimeout(()=>sayChunks(list,k+1,my,done),pause(ch.gap||'colon'));else done()};
  u.onend=next;u.onerror=e=>{if(e.error!=='interrupted'&&e.error!=='canceled')next()};
  synth.speak(u);
}
function speak(i){
  if(i>=ST.S.length){stop();return}
  const my=token,s=ST.S[i];cur=i;show(i);
  const list=splitForVoice(Core.chunks(DOC.W,s));
  if(!list.length){timer=setTimeout(()=>{if(my===token)speak(i+1)},60);return}
  sayChunks(list,0,my,()=>{
    clearRects('hw');const n=ST.S[i+1];
    let w=s.head?pause('afterHead'):s.paraEnd?pause('para'):pause('sent');
    if(n&&n.head&&!s.head)w=pause('beforeHead');
    if(n&&n.sec!==s.sec)w=Math.max(w,pause('beforeHead')*1.3);
    timer=setTimeout(()=>{if(my===token)speak(i+1)},w);
  });
}
function halt(){token++;clearTimeout(timer);if(synth)synth.cancel()}
function restart(){halt();const my=token;setTimeout(()=>{if(my===token&&playing)speak(cur)},80)}
function play(){if(!ST||!ST.S.length)return;playing=true;playB.textContent='❚❚ Pause';restart()}
function stop(){playing=false;halt();playB.textContent='▶ Play';clearRects('hw')}
function jump(i){if(!ST)return;cur=Math.max(0,Math.min(ST.S.length-1,i));if(playing)restart();else show(cur)}
playB.onclick=()=>playing?stop():play();
$('back').onclick=()=>jump(cur-1);$('fwd').onclick=()=>jump(cur+1);
$('prevsec').onclick=()=>{const k=ST.S[cur].sec;jump(ST.secs[cur===ST.secs[k].first&&k>0?k-1:k].first)};
$('nextsec').onclick=()=>{const k=ST.S[cur].sec;if(k<ST.secs.length-1)jump(ST.secs[k+1].first)};
document.addEventListener('keydown',e=>{if($('app').hidden||e.ctrlKey||e.metaKey||e.altKey||/SELECT|INPUT/.test(e.target.tagName)||e.target.id==='grip')return;
  if(e.code==='Space'&&e.target.tagName!=='BUTTON'){e.preventDefault();playB.click()}
  if(e.key==='ArrowRight')jump(cur+1);if(e.key==='ArrowLeft')jump(cur-1);
  if(e.key==='+'||e.key==='=')setZoom(zi+1);if(e.key==='-')setZoom(zi-1)});

/* ---------- zoom ---------- */
const ZOOMS=[0.5,0.67,0.8,0.9,1,1.25,1.5,1.75,2,2.5,3];let zi=ZOOMS.indexOf(parseFloat(store.get('zoom')));if(zi<0)zi=4;
function setZoom(k){zi=Math.max(0,Math.min(ZOOMS.length-1,k));zoom=ZOOMS[zi];
  pagesEl.style.setProperty('--zoom',zoom);pagesEl.classList.toggle('zoomed',zoom>1);$('zl').textContent=Math.round(zoom*100)+'%';store.set('zoom',zoom);
  rerenderVisible();const el=document.querySelector('.hl');if(el)setTimeout(()=>within(pdfPane,el,true),60)}
$('zin').onclick=()=>setZoom(zi+1);$('zout').onclick=()=>setZoom(zi-1);$('zl').onclick=()=>setZoom(4);
setZoom(zi);

/* ---------- resizable split ---------- */
const grip=$('grip'),mq=matchMedia('(max-width:900px)'),narrow=()=>mq.matches;
function setSplit(v,save){v=Math.max(20,Math.min(80,v));main.style.setProperty(narrow()?'--splitv':'--split',v+'%');grip.setAttribute('aria-valuenow',Math.round(v));grip.setAttribute('aria-orientation',narrow()?'horizontal':'vertical');if(save)store.set(narrow()?'splitv':'split',v)}
function loadSplit(){const v=parseFloat(store.get(narrow()?'splitv':'split'));setSplit(Number.isFinite(v)?v:(narrow()?46:58))}
loadSplit();mq.addEventListener('change',loadSplit);
let dragging=false;
grip.addEventListener('pointerdown',e=>{dragging=true;grip.classList.add('drag');grip.setPointerCapture(e.pointerId);document.body.style.userSelect='none'});
grip.addEventListener('pointermove',e=>{if(!dragging)return;const r=main.getBoundingClientRect();setSplit(narrow()?(e.clientY-r.top)/r.height*100:(e.clientX-r.left)/r.width*100,false)});
const endDrag=()=>{if(!dragging)return;dragging=false;grip.classList.remove('drag');document.body.style.userSelect='';setSplit(parseFloat(grip.getAttribute('aria-valuenow')),true);rerenderVisible()};
grip.addEventListener('pointerup',endDrag);grip.addEventListener('pointercancel',endDrag);
grip.addEventListener('dblclick',()=>{setSplit(narrow()?46:58,true);rerenderVisible()});
grip.addEventListener('keydown',e=>{const v=parseFloat(grip.getAttribute('aria-valuenow'));
  if(['ArrowLeft','ArrowUp'].includes(e.key)){e.preventDefault();setSplit(v-3,true);rerenderVisible()}
  if(['ArrowRight','ArrowDown'].includes(e.key)){e.preventDefault();setSplit(v+3,true);rerenderVisible()}});


/* ---------- desktop app bridge (only when running as installed software) ---------- */
const NATIVE=window.native&&window.native.desktop?window.native:null;
if(NATIVE){
  document.documentElement.classList.add('desktop');
  const toAB=d=>d instanceof ArrayBuffer?d:d.buffer.slice(d.byteOffset,d.byteOffset+d.byteLength);
  const pickNative=async()=>{showErr('');const f=await NATIVE.pickFile();if(f)openBuffer(toAB(f.data),f.name)};
  $('pick').onclick=e=>{e.stopPropagation();pickNative()};
  drop.onclick=()=>pickNative();
  drop.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pickNative()}};
  NATIVE.onOpenFile(f=>openBuffer(toAB(f.data),f.name));
  NATIVE.onCommand(c=>{
    if(c==='home'){if(!$('app').hidden)$('home').click();return}
    if($('app').hidden)return;
    ({play:()=>playB.click(),next:()=>jump(cur+1),prev:()=>jump(cur-1),nextsec:()=>$('nextsec').click(),prevsec:()=>$('prevsec').click(),
      zin:()=>setZoom(zi+1),zout:()=>setZoom(zi-1),z100:()=>setZoom(4)}[c]||(()=>{}))();
  });
  if(NATIVE.platform==='darwin'&&$('howOpen'))$('howOpen').innerHTML='You can also right-click a PDF in Finder and choose <b>Open With &gt; StudyDesk PDF</b>, or drop it on the app in the Dock.';
  NATIVE.ready();
}

/* ---------- hook for the browser extension ---------- */
window.plr={open:(buf,name)=>openBuffer(buf,name),showErr,isOpen:()=>!$('app').hidden,current:()=>CUR,stop};

showRecent();
})();
