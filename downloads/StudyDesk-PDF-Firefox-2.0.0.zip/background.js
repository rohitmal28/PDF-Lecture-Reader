'use strict';
/* StudyDesk PDF — browser extension background
   Works as a service worker (Chrome, Edge, Brave, Opera, Vivaldi) and as an event page (Firefox). */
const api=globalThis.browser??globalThis.chrome;
const READER=api.runtime.getURL('reader.html');

/* Is this address a PDF? Quick check on the address first, then ask the site. */
function looksLikePdf(url){
  try{
    const u=new URL(url);
    if(/\.pdf$/i.test(u.pathname))return true;
    if(/(^|\.)arxiv\.org$/i.test(u.hostname)&&/^\/pdf\//.test(u.pathname))return true;
  }catch(e){}
  return false;
}
async function isPdf(url){
  if(!url||!/^(https?|file):/i.test(url))return false;
  if(looksLikePdf(url))return true;
  if(!/^https?:/i.test(url))return false;
  try{
    const ctl=new AbortController(),t=setTimeout(()=>ctl.abort(),2500);
    const r=await fetch(url,{method:'HEAD',credentials:'include',signal:ctl.signal});
    clearTimeout(t);
    return /application\/(x-)?pdf/i.test(r.headers.get('content-type')||'');
  }catch(e){return false}
}

async function openReader(src,afterTab,tool){
  let url=src?READER+'?src='+encodeURIComponent(src)+(tool?'&tool='+tool:''):READER+(tool?'#'+tool:'');
  const opts={url};
  if(afterTab&&typeof afterTab.index==='number'){opts.index=afterTab.index+1;if(afterTab.windowId!==undefined)opts.windowId=afterTab.windowId}
  try{await api.tabs.create(opts)}catch(e){await api.tabs.create({url})}
}

/* Toolbar button (and Alt+Shift+R): read the PDF in this tab, or open the reader. */
async function handleAction(tab){
  const src=tab&&await isPdf(tab.url)?tab.url:'';
  await openReader(src,tab);
}
api.action.onClicked.addListener(handleAction);
globalThis.plrHandleAction=handleAction; // used by the automated tests

/* Right-click menus */
const PDF_LINKS=['*://*/*.pdf*','*://*/*.PDF*','*://arxiv.org/pdf/*','file:///*.pdf*','file:///*.PDF*'];
function createMenus(){
  const add=props=>{try{api.contextMenus.create(props,()=>void api.runtime.lastError)}catch(e){}};
  api.contextMenus.removeAll(()=>{
    void api.runtime.lastError;
    add({id:'plr-link',title:'Read aloud with StudyDesk PDF',contexts:['link'],targetUrlPatterns:PDF_LINKS});
    add({id:'plr-page',title:'Read this PDF aloud',contexts:['page'],documentUrlPatterns:PDF_LINKS});
    add({id:'plr-edit-link',title:'Edit this PDF',contexts:['link'],targetUrlPatterns:PDF_LINKS});
    add({id:'plr-edit-page',title:'Edit this PDF',contexts:['page'],documentUrlPatterns:PDF_LINKS});
    add({id:'plr-open',title:'Open StudyDesk PDF',contexts:['action']});
    add({id:'plr-merge',title:'Merge PDFs',contexts:['action']});
    add({id:'plr-images',title:'Images to PDF',contexts:['action']});
    add({id:'plr-edit',title:'Edit a PDF',contexts:['action']});
  });
}
api.runtime.onInstalled.addListener(createMenus);
api.runtime.onStartup.addListener(createMenus);
api.contextMenus.onClicked.addListener((info,tab)=>{
  if(info.menuItemId==='plr-link')openReader(info.linkUrl,tab);
  else if(info.menuItemId==='plr-page')openReader(info.pageUrl||(tab&&tab.url),tab);
  else if(info.menuItemId==='plr-open')openReader('',tab);
  else if(info.menuItemId==='plr-edit-link')openReader(info.linkUrl,tab,'edit');
  else if(info.menuItemId==='plr-edit-page')openReader(info.pageUrl||(tab&&tab.url),tab,'edit');
  else if(/^plr-(merge|images|edit)$/.test(info.menuItemId))openReader('',tab,info.menuItemId.slice(4));
});
