/* StudyDesk PDF — text extraction and lecture structure (shared by app and tests) */
const Core=(()=>{
const ABBR=/^(e\.g|i\.e|etc|vs|mr|mrs|ms|dr|prof|fig|figs|eq|eqs|no|nos|vol|approx|al|inc|ltd|jr|sr|st|sec|ch|pp|p|cf|resp|dept|univ)\.$/i;
const BULLET=/^([•●▪◦■□➢►✓✔\-–*]|\(?\d{1,2}[.)]|\(?[a-z][.)]|\(?[ivx]{1,4}[.)])$/i;
const median=a=>{if(!a.length)return 0;const b=[...a].sort((x,y)=>x-y);return b[b.length>>1]};

async function extract(pdf,lib,measure,onProgress){
  const pages=[],W=[];
  for(let p=0;p<pdf.numPages;p++){
    const page=await pdf.getPage(p+1);const vp=page.getViewport({scale:1});
    const tc=await page.getTextContent();
    const P={w:vp.width,h:vp.height,wstart:W.length,lines:[]};
    let line=null,lastBase=null,lastEnd=null,eol=true,prevWord=null,trailingSpace=true;
    for(const it of tc.items){
      if(typeof it.str!=='string')continue;
      const s=it.str;
      if(!s.trim()){if(it.hasEOL)eol=true;if(s.length)trailingSpace=true;continue}
      const tx=lib.Util.transform(vp.transform,it.transform);
      const fs=Math.hypot(tx[2],tx[3])||it.height||10;
      if(fs<2)continue;
      if(Math.abs(tx[1])>Math.abs(tx[0])*0.3)continue; // rotated or vertical text
      const x=tx[4],base=tx[5],wpx=Math.abs(it.width*vp.scale)||s.length*fs*0.5;
      const newLine=eol||lastBase===null||Math.abs(base-lastBase)>fs*0.45||x<lastEnd-fs*1.5;
      if(newLine){line={words:[],fs:0};P.lines.push(line);prevWord=null;trailingSpace=true}
      const gap=lastEnd===null||newLine?1e9:x-lastEnd;
      const total=measure(s,fs)||1,k=wpx/total;
      let off=0;const pieces=s.split(/(\s+)/);
      pieces.forEach((pc,pi)=>{
        if(!pc)return;const w=measure(pc,fs)*k;
        if(/^\s+$/.test(pc)){off+=w;trailingSpace=true;return}
        const x0=x+off,x1=x+off+w;
        const glue=prevWord&&!trailingSpace&&pi===0&&gap<fs*0.18;
        if(glue){prevWord.t+=pc;prevWord.x1=x1/vp.width*100}
        else{
          const wd={p,t:pc,fs,x0:x0/vp.width*100,x1:x1/vp.width*100,y0:(base-fs*0.86)/vp.height*100,y1:(base+fs*0.24)/vp.height*100};
          W.push(wd);line.words.push(W.length-1);prevWord=wd;
        }
        trailingSpace=false;off+=w;
      });
      line.fs=Math.max(line.fs,fs);
      lastBase=base;lastEnd=x+wpx;eol=!!it.hasEOL;
      if(/\s$/.test(s))trailingSpace=true;
    }
    P.lines=P.lines.filter(l=>l.words.length);
    for(const l of P.lines){const ws=l.words.map(i=>W[i]);
      l.y0=Math.min(...ws.map(w=>w.y0));l.y1=Math.max(...ws.map(w=>w.y1));l.x0=Math.min(...ws.map(w=>w.x0));l.x1=Math.max(...ws.map(w=>w.x1));
      l.text=ws.map(w=>w.t).join(' ');}
    P.wend=W.length;pages.push(P);
    if(onProgress)await onProgress(p+1,pdf.numPages);
  }
  return {pages,W};
}

function structure(doc){
  const {pages,W}=doc,N=pages.length;
  // 1. repeated headers / footers and page numbers
  const keyCount=new Map(),keyOf=l=>l.text.replace(/\d+/g,'#').replace(/\s+/g,' ').trim().toLowerCase();
  pages.forEach(P=>{const seen=new Set();P.lines.forEach(l=>{if(l.y0<9||l.y1>91){const k=keyOf(l);if(!seen.has(k)){seen.add(k);keyCount.set(k,(keyCount.get(k)||0)+1)}}})});
  const rep=N<2?Infinity:Math.max(2,Math.ceil(N*0.3));
  pages.forEach(P=>P.lines.forEach(l=>{
    const edge=l.y0<9||l.y1>91;
    l.skip=edge&&(keyCount.get(keyOf(l))>=rep||/^(page\s*)?[#\divxlc.\-–|·\s]+(of\s*\d+)?$/i.test(l.text.trim())&&l.text.length<14);
    if(l.skip)l.words.forEach(i=>W[i].skip=true);
    const last=W[l.words[l.words.length-1]];last.le=true;
    if(l.words.filter(i=>/^[.…·]+$/.test(W[i].t)).length>=3)last.brk=true;
    l.short=l.words.length<=10;if(l.short)last.short=true;
  }));
  // 2. body font size and line spacing
  const sizeChars=new Map();
  pages.forEach(P=>P.lines.forEach(l=>{if(l.skip)return;const k=Math.round(l.fs*2)/2;sizeChars.set(k,(sizeChars.get(k)||0)+l.text.length)}));
  let body=10,bc=-1;sizeChars.forEach((c,k)=>{if(c>bc){bc=c;body=k}});
  const gaps=[];
  pages.forEach(P=>{const ls=P.lines.filter(l=>!l.skip);for(let i=1;i<ls.length;i++){const g=(ls[i].y0-ls[i-1].y1)*P.h/100;if(g>-2&&Math.abs(ls[i].fs-body)<1&&Math.abs(ls[i-1].fs-body)<1)gaps.push(g)}});
  const lineGap=Math.max(1,median(gaps.filter(g=>g>=0)));
  const isHead=l=>l.fs>=body*1.15&&l.text.length<=140&&l.words.length<=22;
  // 3. blocks
  const blocks=[];let cur=null,prevLine=null,prevPage=-1;
  pages.forEach((P,pi)=>P.lines.forEach(l=>{
    if(l.skip)return;
    const head=isHead(l),firstTok=W[l.words[0]].t;
    let start=!cur;
    if(cur){
      const gap=pi===prevPage?(l.y0-prevLine.y1)*P.h/100:null;
      if(head!==(cur.type==='h'))start=true;
      else if(head&&Math.abs(l.fs-cur.fs)>0.6)start=true;
      else if(gap!==null&&gap>Math.max(lineGap*1.7,body*0.55))start=true;
      else if(gap!==null&&gap<-body*1.5)start=true; // new column
      else if(!head&&BULLET.test(firstTok)&&l.words.length>1)start=true;
      else if(pi!==prevPage){
        const lastT=W[cur.ws[cur.ws.length-1]].t;
        start=head||/[.!?:]["'”’)\]]*$/.test(lastT)||!/^[a-z(]/.test(firstTok);
      }
      else if(head&&l.y0-prevLine.y1>l.fs*0.9)start=true;
    }
    if(start){cur={type:head?'h':'p',fs:l.fs,ws:[],lines:[],page:pi};blocks.push(cur)}
    cur.ws.push(...l.words);cur.lines.push(l);prevLine=l;prevPage=pi;
  }));
  // heading levels
  const hs=[...new Set(blocks.filter(b=>b.type==='h').map(b=>Math.round(b.fs*2)/2))].sort((a,b)=>b-a);
  blocks.forEach(b=>{if(b.type==='h'){b.level=Math.min(3,hs.indexOf(Math.round(b.fs*2)/2)+1);
    if(b.ws.length>30)b.type='p';}}); // very long "headings" are really big text
  // 4. sentences
  const S=[];const lineEndSet=new Set();blocks.forEach(b=>b.lines.forEach(l=>lineEndSet.add(l.words[l.words.length-1])));
  const endsSentence=(t,next)=>{
    if(/^[.…·]+$/.test(t))return false;
    if(!/[.!?]["'”’)\]]*$/.test(t))return false;
    if(ABBR.test(t)||/^[A-Z]\.$/.test(t))return false;
    if(!next)return true;
    return /^[A-Z0-9"'“‘(\[•●\-–]/.test(next.t);
  };
  blocks.forEach((b,bi)=>{
    b.sents=[];
    const push=(ws,extra)=>{if(!ws.length)return;S.push(Object.assign({ws,block:bi,head:b.type==='h'},extra||{}));b.sents.push(S.length-1)};
    if(b.type==='h'){push(b.ws.slice());return}
    let acc=[];
    b.ws.forEach((wi,k)=>{
      acc.push(wi);const t=W[wi].t,next=W[b.ws[k+1]];
      const n=acc.length;
      if(W[wi].brk||endsSentence(t,next)||(n>=26&&lineEndSet.has(wi)&&!/[,;:]$/.test(t)&&next&&/^[A-Z•●]/.test(next.t))||(n>=38&&/[,;:]$/.test(t))||n>=60){push(acc);acc=[]}
    });
    push(acc);
  });
  S.forEach((s,i)=>{const b=blocks[s.block];s.paraEnd=b.sents[b.sents.length-1]===i;s.page=W[s.ws[0]].p});
  // 5. sections
  const heads=blocks.map((b,i)=>[b,i]).filter(([b])=>b.type==='h'&&b.sents.length);
  let secLevel=0;
  for(let L=1;L<=3;L++){const c=heads.filter(([b])=>b.level<=L).length;secLevel=L;if(c>=3)break}
  const secHeads=heads.filter(([b])=>b.level<=secLevel);
  const secs=[];
  if(secHeads.length>=2){
    const firstSent=secHeads[0][0].sents[0];
    if(firstSent>0)secs.push({title:'Opening pages',first:0});
    secHeads.forEach(([b])=>secs.push({title:textOf(W,b.ws,90),first:b.sents[0]}));
  }else{
    // fall back to one section per page
    let lastP=-1;S.forEach((s,i)=>{if(s.page!==lastP){secs.push({title:'Page '+(s.page+1),first:i});lastP=s.page}});
  }
  secs.forEach((x,k)=>{x.last=(k<secs.length-1?secs[k+1].first:S.length)-1;x.page=S[x.first]?S[x.first].page:0});
  S.forEach((s,i)=>{});
  let k=0;S.forEach((s,i)=>{while(k<secs.length-1&&i>=secs[k+1].first)k++;s.sec=k});
  const w2s=new Int32Array(W.length).fill(-1);S.forEach((s,i)=>s.ws.forEach(w=>w2s[w]=i));
  return {blocks,S,secs,w2s,body,lineGap};
}

function textOf(W,ws,max){let out='';ws.forEach((wi,k)=>{const t=W[wi].t,nx=W[ws[k+1]];
  if(/[A-Za-z]-$/.test(t)&&nx&&/^[a-z]/.test(nx.t)&&W[wi].y0!==nx.y0)out+=t.slice(0,-1);else out+=t+(nx?' ':'')});
  out=out.replace(/\s+/g,' ').trim();return max&&out.length>max?out.slice(0,max-1)+'…':out}

/* how a word should sound */
const MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
/* dates are read the Indian way: day first (DD/MM/YYYY) */
function sayDate(t){
  const m=t.match(/^\(?(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2}|\d{4})\)?([,.;:!?)]*)$/);
  if(!m)return null;
  const d=+m[1],mo=+m[2];let y=m[3];
  if(d<1||d>31||mo<1||mo>12)return null;
  if(y.length===2)y=(+y>50?'19':'20')+y;
  return d+' '+MONTHS[mo-1]+' '+y+(m[4]||'');
}
function sayWord(t){
  let s=t;
  const dt=sayDate(s);if(dt)return dt;
  if(/^e\.g\.?,?$/i.test(s))return 'for example'+(/,$/.test(s)?',':'');
  if(/^i\.e\.?,?$/i.test(s))return 'that is'+(/,$/.test(s)?',':'');
  if(/^etc\.?,?$/i.test(s))return 'etcetera'+(/[.,]$/.test(s)?s.slice(-1):'');
  if(/^vs\.?$/i.test(s))return 'versus';
  if(/^[•●▪◦■□➢►✓✔]+$/.test(s))return '';
  if(/^[.…·]+$/.test(s))return '';
  if(/^[-–—]$/.test(s))return ',';
  if(s==='/')return 'divided by';
  if(/^[←⇐]$/.test(s))return ',';
  if(s==='+')return 'plus';if(s==='−')return 'minus';
  s=s.replace(/[•●▪◦■□➢►✓✔]/g,'')
   .replace(/^[-−](?=\d)/,'minus ').replace(/→|⇒|⟶|->/g,' to ').replace(/←|<-/g,', ').replace(/·/g,', ').replace(/×/g,' times ').replace(/÷/g,' divided by ')
   .replace(/≈/g,' about ').replace(/≥|>=/g,' at least ').replace(/≤|<=/g,' at most ').replace(/≠|!=/g,' not equal to ').replace(/±/g,' plus or minus ')
   .replace(/(\d)\s?%/g,'$1 percent').replace(/%/g,' percent').replace(/&/g,' and ').replace(/==?/g,' equals ').replace(/\^/g,' to the power ')
   .replace(/([A-Za-z])\/([A-Za-z])/g,'$1 or $2')
   .replace(/([A-Za-z_][A-Za-z\d_]*|\))\.([A-Za-z_][A-Za-z\d_]*)/g,(m,a,b)=>(a.length===1&&b.length===1)?m:a+' dot '+b)
   .replace(/_/g,' ').replace(/[(){}\[\]<>#*`"“”|]/g,' ').replace(/[–—]/g,', ');
  return s.replace(/\s+/g,' ').trim();
}
/* split a sentence into spoken chunks with char offsets for word highlighting */
function chunks(W,s,lineEnd){
  const out=[];let c={text:'',map:[]};
  s.ws.forEach((wi,k)=>{
    const t=W[wi].t,nx=W[s.ws[k+1]];
    let say=sayWord(t);
    const joinNext=/[A-Za-z]-$/.test(t)&&nx&&/^[a-z]/.test(nx.t)&&W[wi].y0!==nx.y0;
    if(joinNext)say=sayWord(t.slice(0,-1));
    if(say){c.map.push([c.text.length,wi]);c.text+=say+(joinNext?'':' ')}
    const w=W[wi];
    const brk=nx&&((/:$/.test(t)&&c.map.length<=10)||(/[;:]$/.test(t)&&s.ws.length>22)||(w.le&&w.short&&!/[,.;:!?]$/.test(t)&&/^[A-Z0-9]/.test(nx.t)));
    if(brk){out.push(c);c={text:'',map:[]}}
  });
  if(c.text.trim())out.push(c);
  return out.filter(x=>x.text.trim());
}
return {extract,structure,textOf,sayWord,chunks};
})();
if(typeof module!=='undefined')module.exports=Core;
