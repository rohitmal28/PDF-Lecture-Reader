'use strict';
/* StudyDesk PDF — extension-only parts of the reader page:
   open a PDF passed by the toolbar button or right-click menu, open a pasted link,
   and ask for permission to download from a site when the browser needs it. */
(()=>{
const api=globalThis.browser??globalThis.chrome;
const $=id=>document.getElementById(id);
const plr=window.plr;
const isFirefox=location.protocol==='moz-extension:';

/* ---- start screen additions ---- */
const box=document.createElement('form');
box.className='linkbox';box.id='linkbox';box.noValidate=true;
box.innerHTML=`<label for="linkurl">Or open a PDF from the web</label>
  <div class="linkrow"><input id="linkurl" type="url" inputmode="url" placeholder="Paste a link to a PDF" autocomplete="off" spellcheck="false"><button type="submit">Open link</button></div>`;
$('drop').after(box);
const ask=document.createElement('div');
ask.className='ask';ask.id='ask';ask.hidden=true;ask.setAttribute('role','alert');
box.after(ask);

const how=document.querySelector('.how ol');
if(how){
  const tips=[
    'While a PDF is open in a tab, click the <b>StudyDesk PDF</b> button in the toolbar, or press <b>Alt+Shift+R</b>.',
    'Right-click a link to a PDF and choose <b>Read aloud with StudyDesk PDF</b>, or <b>Edit this PDF</b> to add text, highlight or change pages.'
  ];
  tips.reverse().forEach(t=>{const li=document.createElement('li');li.innerHTML=t;how.prepend(li)});
}

/* ---- helpers ---- */
function showAsk(html,buttons){
  ask.innerHTML=`<p>${html}</p><div class="askrow"></div>`;
  const row=ask.querySelector('.askrow');
  buttons.forEach(([label,fn,primary])=>{const b=document.createElement('button');b.type='button';b.textContent=label;if(primary)b.className='primary';b.onclick=fn;row.appendChild(b)});
  ask.hidden=false;
  const first=row.querySelector('button');if(first)first.focus();
}
const hideAsk=()=>{ask.hidden=true;ask.innerHTML=''};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function loading(text,frac){
  $('loading').hidden=false;$('loadtxt').textContent=text;
  $('loadbar').style.width=frac==null?'0%':Math.round(frac*100)+'%';
}
const doneLoading=()=>{$('loading').hidden=true};
function nameFrom(url,disposition){
  const m=/filename\*=(?:UTF-8'')?([^;]+)|filename="?([^";]+)"?/i.exec(disposition||'');
  let n='';
  if(m){try{n=decodeURIComponent((m[1]||m[2]).trim())}catch(e){n=(m[1]||m[2]).trim()}}
  if(!n){try{const u=new URL(url);n=decodeURIComponent(u.pathname.split('/').filter(Boolean).pop()||u.hostname)}catch(e){n='document'}}
  n=n.replace(/[\\/:*?"<>|]+/g,' ').trim()||'document';
  return /\.pdf$/i.test(n)?n:n+'.pdf';
}
const originPattern=url=>{const u=new URL(url);return u.protocol==='file:'?'file:///*':`${u.protocol}//${u.hostname}/*`};
async function hasAccess(url){try{return await api.permissions.contains({origins:[originPattern(url)]})}catch(e){return false}}
function requestAccess(url){ // must be called straight from a click
  try{return Promise.resolve(api.permissions.request({origins:[originPattern(url)]})).catch(()=>false)}catch(e){return Promise.resolve(false)}
}

/* ---- downloading ---- */
function readFileUrl(url){ // fetch() cannot read file:// addresses, XMLHttpRequest can
  return new Promise((res,rej)=>{
    const x=new XMLHttpRequest();x.open('GET',url);x.responseType='arraybuffer';
    x.onprogress=e=>{if(e.lengthComputable)loading('Reading '+nameFrom(url)+'…',e.loaded/e.total)};
    x.onload=()=>x.response&&x.response.byteLength?res({buf:x.response,name:nameFrom(url)}):rej(new Error('empty'));
    x.onerror=()=>rej(new Error('file'));x.send();
  });
}
async function download(url){
  const r=await fetch(url,{credentials:'include',redirect:'follow'});
  if(!r.ok){const e=new Error('http');e.status=r.status;throw e}
  const total=+r.headers.get('content-length')||0,name=nameFrom(r.url||url,r.headers.get('content-disposition'));
  if(!r.body||!total){loading('Downloading '+name+'…');return {buf:await r.arrayBuffer(),name}}
  const reader=r.body.getReader(),parts=[];let got=0;
  for(;;){const {done,value}=await reader.read();if(done)break;parts.push(value);got+=value.length;loading(`Downloading ${name}… ${(got/1048576).toFixed(1)} of ${(total/1048576).toFixed(1)} MB`,got/total)}
  const buf=new Uint8Array(got);let o=0;for(const p of parts){buf.set(p,o);o+=p.length}
  return {buf:buf.buffer,name};
}
const isPdfBytes=buf=>{const b=new Uint8Array(buf,0,Math.min(1024,buf.byteLength));for(let i=0;i<b.length-4;i++)if(b[i]===0x25&&b[i+1]===0x50&&b[i+2]===0x44&&b[i+3]===0x46)return true;return false};

async function openUrl(url,fromClick){
  hideAsk();plr.showErr('');
  let u;try{u=new URL(url)}catch(e){plr.showErr('That is not a web address. Paste the full link, starting with https://');return}
  if(!/^(https?|file):$/.test(u.protocol)){plr.showErr('Only links starting with https://, http:// or file:// can be opened.');return}

  if(u.protocol==='file:'){
    if(isFirefox){
      showAsk(`Firefox doesn't let add-ons open files from your computer by their address. Drag <b>${esc(nameFrom(url))}</b> onto this page, or click <b>Choose a PDF</b>.`,[['Choose a PDF',()=>{hideAsk();$('file').click()},true],['Close',hideAsk]]);
      return;
    }
    let allowed=true;
    try{allowed=await api.extension.isAllowedFileSchemeAccess()}catch(e){}
    if(!allowed){
      showAsk(`To open PDFs from your computer with the toolbar button, turn on <b>Allow access to file URLs</b> for StudyDesk PDF on your browser's Extensions page. Or simply drag <b>${esc(nameFrom(url))}</b> onto this page.`,
        [['Open extension settings',()=>{api.tabs.create({url:'chrome://extensions/?id='+api.runtime.id}).catch?.(()=>{})},true],['Choose a PDF instead',()=>{hideAsk();$('file').click()}],['Close',hideAsk]]);
      return;
    }
  }else if(!fromClick&&!(await hasAccess(url))){
    showAsk(`StudyDesk PDF needs your permission to download PDFs from <b>${esc(u.hostname)}</b>. It only reads the PDF; nothing is sent anywhere.`,
      [['Allow',()=>{requestAccess(url).then(ok=>ok?openUrl(url,true):showAsk(`Permission was not given, so the PDF can't be downloaded. You can save it to your computer and drag it here instead.`,[['Close',hideAsk,true]]))},true],['Cancel',hideAsk]]);
    return;
  }

  loading('Opening '+nameFrom(url)+'…');
  let got;
  try{got=u.protocol==='file:'?await readFileUrl(url):await download(url)}
  catch(e){
    doneLoading();
    if(e.status===401||e.status===403)plr.showErr(`The site refused the download (error ${e.status}). If you need to sign in to see this PDF, download it, then drag it here.`);
    else if(e.status===404)plr.showErr('That PDF was not found on the site (error 404). Check the link.');
    else if(e.status)plr.showErr(`The site returned an error (${e.status}). Try again later, or download the PDF and drag it here.`);
    else plr.showErr('The PDF could not be downloaded. Check your internet connection, or download it and drag it here.');
    return;
  }
  if(!isPdfBytes(got.buf)){doneLoading();plr.showErr("That link doesn't lead to a PDF file. Open the PDF itself, then try again.");return}
  if(TOOL==='edit'&&window.plrTools){doneLoading();window.plrTools.open('edit',{buf:got.buf,name:got.name});return}
  plr.open(got.buf,got.name);
}

/* ---- paste a link ---- */
box.addEventListener('submit',e=>{
  e.preventDefault();
  const url=$('linkurl').value.trim();if(!url){$('linkurl').focus();return}
  let u;try{u=new URL(url)}catch(err){plr.showErr('That is not a web address. Paste the full link, starting with https://');return}
  if(/^https?:$/.test(u.protocol)){
    // ask for the site permission straight from this click, which browsers require
    requestAccess(url).then(ok=>ok?openUrl(url,true):plr.showErr("Permission was not given, so the PDF can't be downloaded."));
  }else openUrl(url,true);
});

/* ---- PDF passed in by the toolbar button or a right-click ---- */
const params=new URLSearchParams(location.search),src=params.get('src'),TOOL=params.get('tool');
if(src){
  history.replaceState(null,'',location.pathname); // a reload shows the start screen; the PDF is in Recent documents
  openUrl(src,false);
}
})();
